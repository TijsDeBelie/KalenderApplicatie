   KalenderApplicatie
   
   BELANGRIJK : Om het project te laten runnen moet je het database script eerst nog runnen
   In de klasse Sqlconnect is er een keuze of U de geintegreerde database wilt gebruiken (mogelijks moet u het pad veranderen) of de database connecteren met het script.
   
   
   Een afspraak kan snel worden ingevoerd door rechts te klikken op de kalender. 
   
   
  