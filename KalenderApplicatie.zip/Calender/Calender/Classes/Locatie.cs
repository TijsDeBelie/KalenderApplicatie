﻿namespace Calender
{
    public class Locatie
    {

        public Locatie(string naam)
        {
            Naam = naam;
        }

        public string Naam { get; set; }
    }
}